Executar python main.py
